# car-rental-project
First install xampp server.
place the entire project in xampp/htdocs folder in your system.
Now run apache mySQL in the xampp server.
Now open localhost/phpmyadmin in your browser.
Now create now database and import the SQL file.
After importing now open localhost/vehiclerental in the browser.
Admin details USERNAME:admin  PASSWORD:admin
         
