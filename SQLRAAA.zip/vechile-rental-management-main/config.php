<?php

$databaseHost = 'localhost';
$databaseName = 'vehiclerental';
$databaseUsername = 'root';
$databasePassword = '';

$mysqli = mysqli_connect($databaseHost, $databaseUsername, $databasePassword, $databaseName); 
 
?>
