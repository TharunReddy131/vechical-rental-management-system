<!DOCTYPE html>

<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
    <link href="StyleSheet.css" rel="stylesheet" />
    <title></title>
    <asp:ContentPlaceHolder id="head" runat="server">
        <link href="StyleSheet.css" rel="stylesheet" />
    </asp:ContentPlaceHolder>
</head>
<body>
   
    <div>
        
            <div class="header">VEHICLE RENTAL MANAGEMENT SYSTEM
</div>
        
        <div class="menu">
        <div class="navbar">


<div class="dropdown">
    <button class="dropbtn">
        <a href="home2.php">Home </a>
     
    </button>
    
	
  </div>   
  <div class="dropdown">
    <button class="dropbtn">
        <a href="driver_booking_list.php">Booking List</a>
     
    </button>
    
	
  </div>   
  <div class="dropdown">
    <button class="dropbtn">
        <a href="driver_return_list.php">Return List</a>
     
    </button>
    
	
  </div>  
  <div class="dropdown">
    <button class="dropbtn">
        <a href="index.php">Logout </a>
     
    </button>
    
	
  </div>   
 

    </div>


            </div>
</body>
</html>
