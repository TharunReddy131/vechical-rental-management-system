<!DOCTYPE html>

<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
    <link href="StyleSheet.css" rel="stylesheet" />
    <title></title>
    <asp:ContentPlaceHolder id="head" runat="server">
        <link href="StyleSheet.css" rel="stylesheet" />
    </asp:ContentPlaceHolder>
</head>
<body>
   
    <div>
        
            <div class="header">VEHICLE RENTAL MANAGEMENT SYSTEM
</div>
        
        <div class="menu">
        <div class="navbar">


<div class="dropdown">
    <button class="dropbtn">
        <a href="home.php">Home </a>
     
    </button>
    
	
  </div>   
  <div class="dropdown">
    <button class="dropbtn">
        <a href="driver_login.php">Driver </a>
     
    </button>
    
	
  </div>   
  <div class="dropdown">
    <button class="dropbtn">
        <a href="user_login.php">Customer </a>
     
    </button>
    
	
  </div> 
  <div class="dropdown">
    <button class="dropbtn">
        <a href="admin_login.php">Admin </a>
     
    </button>
    
	
  </div>   
 

    </div>


            </div>
</body>
</html>
