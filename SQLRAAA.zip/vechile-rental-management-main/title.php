<?php
echo "Vehicle Rental Management System"
?>